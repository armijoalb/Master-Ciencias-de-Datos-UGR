#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:10:06 2018

@author: alberto
"""

def eliminar_letras(palabra,letra):
    new_palabra = ''
    for l in palabra:
        if l != letra:
            new_palabra += l
            
    
    return new_palabra
            

print(eliminar_letras("hola","a"))
print(eliminar_letras("hola","o"))
