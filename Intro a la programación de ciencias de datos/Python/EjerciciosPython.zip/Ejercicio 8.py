#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:11:57 2018

@author: alberto
"""

def eco_palabra(palabra):
    eco = ''
    for veces in range(len(palabra)):
        eco += palabra
    
    return eco

print(eco_palabra("hola"))