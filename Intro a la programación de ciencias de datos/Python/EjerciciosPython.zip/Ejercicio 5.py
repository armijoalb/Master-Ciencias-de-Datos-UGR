#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:11:07 2018

@author: alberto
"""

def vocales(palabra):
    vocales = []
    vocals = ['a','e','i','o','u']
    for l in palabra:
        if l in vocals:
            vocales.append(l)
    return vocales

print(vocales("hola"))