#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:11:25 2018

@author: alberto
"""

def es_inversa(palabra1, palabra2):
    ini = 0
    fin = len(palabra2)-1
    inversa = True
    
    if len(palabra1) != len(palabra2):
        inversa = False
    else:
        while( ini < len(palabra1) and inversa):
            if(palabra1[ini] != palabra2[fin]):
                inversa = False
            ini += 1
            fin -= 1
                
    return inversa

print(es_inversa("absd","dsba"))