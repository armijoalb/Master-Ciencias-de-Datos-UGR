#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:10:36 2018

@author: alberto
"""

def buscar(palabra,sub):
    sub_index = 0
    index = -1
    for i in range(len(palabra)):
        if palabra[i] == sub[0]:
            index = i
            for j in range(1,len(sub)):
                if i+j >= len(palabra):
                    index = -1
                elif palabra[i+j] != sub[j]:
                    index = -1
        
    return index


print(buscar("hola","la"))
print(buscar("hola","lo"))