#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:12:45 2018

@author: alberto
"""

def anagrama(palabra1,palabra2):
    palabra1_ord = ''.join(sorted(palabra1))
    palabra2_ord = ''.join(sorted(palabra2))
    return palabra1_ord == palabra2_ord

print(anagrama("marta","trama"))
print(anagrama("patatas","hola"))