#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:09:50 2018

@author: alberto
"""


def contar_letras(palabra,letra):
    num_letras = 0
    for l in palabra:
        if(letra == l):
            num_letras += 1
            
    return num_letras

print(contar_letras("hola","a"))
print(contar_letras("hola","e"))