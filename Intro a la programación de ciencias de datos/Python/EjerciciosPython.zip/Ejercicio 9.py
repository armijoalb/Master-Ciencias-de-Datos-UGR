#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:12:10 2018

@author: alberto
"""

def palindromo(frase):
    es_palindromo = True
    mitad = (len(frase)-1)/2
    frase = frase.replace(" ","")
    ini = 0
    fin = len(frase)-1
    while( es_palindromo and ini < mitad
         and fin > mitad):
        
        if frase[ini] != frase[fin]:
            es_palindromo = False
        
        ini += 1
        fin -= 1
    
    return es_palindromo

print(palindromo("a cavar a caravaca"))
print(palindromo("hola hola"))
