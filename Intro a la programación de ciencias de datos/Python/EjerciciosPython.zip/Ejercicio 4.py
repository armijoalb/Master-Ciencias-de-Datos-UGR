#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:10:50 2018

@author: alberto
"""

def num_vocales(palabra):
    vocales = 0
    vocals =  ['a','e','i','o','u']
    for l in palabra:
        if l in vocals:
            vocales += 1
    
    return vocales

print(num_vocales("hola"))
print(num_vocales("pepino"))