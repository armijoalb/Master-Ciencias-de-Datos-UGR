#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:12:22 2018

@author: alberto
"""


def orden_alfabetico(palabra):
    palabra_ord = ''.join(sorted(palabra))
    return palabra_ord == palabra

print(orden_alfabetico("abejo"))
print(orden_alfabetico("hola"))