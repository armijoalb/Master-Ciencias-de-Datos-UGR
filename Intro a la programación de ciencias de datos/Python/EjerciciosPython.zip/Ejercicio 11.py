#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:12:35 2018

@author: alberto
"""

def trocear(palabra,num):
    ini = 0
    trozos = []
    while( (ini+num) < len(palabra)):
        trozos.append(palabra[ini:ini+num])
        ini += num
    
    trozos.append(palabra[ini:])
    return trozos

print(trocear("hola",1))
print(trocear("hola",2))
print(trocear("hola",3))
