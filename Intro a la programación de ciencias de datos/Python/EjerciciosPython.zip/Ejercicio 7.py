#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 17:11:38 2018

@author: alberto
"""

def comunes(palabra1,palabra2):
    caracteres_comunes = ''
    for l in palabra1:
        if l in palabra2 and l not in caracteres_comunes:
            caracteres_comunes += l
    return caracteres_comunes

print(comunes("hola","olaa"))